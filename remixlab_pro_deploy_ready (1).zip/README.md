# RemixLab Pro — Starter

This scaffold provides a starter Vite + React frontend and a minimal Express server.

## Features included
- React + Vite frontend
- Tailwind placeholders (configure Tailwind separately)
- Basic Web Audio API wiring in the demo component
- Server folder with an upload endpoint (demo)
- Guidance for wavesurfer.js, Tone.js and serverless STEM separation / ffmpeg

## Quickstart
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the frontend dev server:
   ```bash
   npm run dev
   ```
3. Start the server (in a separate terminal):
   ```bash
   npm run server
   ```

## Next steps (recommended)
- Add wavesurfer.js for waveform editing: `npm i wavesurfer.js` and follow their docs.
- Implement stem separation server-side (e.g., Spleeter or Demucs) and store stems in S3.
- Use an OfflineAudioContext or server-side ffmpeg mixing for accurate exports.

## Serverless / Worker notes
Use a job queue (BullMQ or similar) and a worker process to run heavy ML tasks. For ffmpeg mixing use `fluent-ffmpeg` or call `ffmpeg` CLI.


## Added features in this update

- Wavesurfer.js integration for per-track waveform display.
- Per-track start/end trim sliders and a `Trim & Export` button to download the selected region as WAV.
- TailwindCSS and PostCSS config files added (tailwind.config.cjs, postcss.config.cjs). Run `npm run build:css` to generate styles if needed.

### Notes
- Install dependencies with `npm install` (this will pull wavesurfer.js and tailwind/postcss packages).
- The Trim & Export runs fully client-side using OfflineAudioContext and will download a WAV file for the selected region.


## 🚀 One-Click Deploy

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new)

Follow the platform prompts and add required environment variables if needed.
