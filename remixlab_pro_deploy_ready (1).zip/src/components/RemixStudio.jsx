import React, { useRef, useState, useEffect } from 'react';
import WaveSurfer from 'wavesurfer.js';

export default function RemixStudio(){
  const [tracks, setTracks] = useState([]);
  const audioCtxRef = useRef(null);

  useEffect(()=>{
    if (!audioCtxRef.current){
      audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    }
  },[]);

  async function handleFiles(files){
    const arr = Array.from(files);
    const ctx = audioCtxRef.current;
    const decoded = await Promise.all(arr.map(async (f,i)=>{
      const blobUrl = URL.createObjectURL(f);
      const arrayBuffer = await f.arrayBuffer();
      const buffer = await ctx.decodeAudioData(arrayBuffer.slice(0));
      return { id: Date.now()+i, name: f.name, file: f, buffer, url: blobUrl, start: 0, end: buffer.duration };
    }));
    setTracks(prev=>[...prev,...decoded]);
  }

  function removeTrack(id){
    setTracks(prev=>prev.filter(t=>t.id!==id));
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-slate-800 text-slate-100 p-6">
      <header className="max-w-6xl mx-auto flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">RemixLab Pro</h1>
          <p className="text-slate-300">AI-powered browser studio</p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto grid lg:grid-cols-3 gap-6">
        <section className="lg:col-span-2 bg-slate-900 p-4 rounded-2xl">
          <UploadArea onFiles={handleFiles} />
          <div className="mt-4">
            {tracks.length===0? <div className="py-8 text-center text-slate-500">No tracks</div> : tracks.map(t=> (
              <TrackRow key={t.id} track={t} remove={()=>removeTrack(t.id)} update={(patch)=>{
                setTracks(prev=>prev.map(x=> x.id===t.id? {...x,...patch}: x));
              }} />
            ))}
          </div>
        </section>

        <aside className="bg-slate-900 p-4 rounded-2xl">
          <h3 className="font-semibold mb-2">Visualizer</h3>
          <canvas id="vis" width="600" height="160" className="w-full bg-black rounded" />
          <div className="mt-4 text-slate-400 text-sm">Per-track waveforms with simple trim controls. Use the sliders to set trim start/end and click "Trim & Export" to download the trimmed region.</div>
        </aside>
      </main>
    </div>
  )
}

function UploadArea({ onFiles }){
  const fileRef = useRef(null)
  return (
    <div className="p-4 rounded border-2 border-dashed border-slate-700">
      <input ref={fileRef} type="file" accept="audio/*" multiple className="hidden" onChange={e=>onFiles(e.target.files)} />
      <div className="flex flex-col items-center gap-3">
        <div className="text-3xl">🎧</div>
        <div className="text-slate-300">Drag & drop audio files here or click to upload</div>
        <div className="flex gap-2">
          <button onClick={()=>fileRef.current?.click()} className="px-3 py-2 bg-emerald-500 rounded text-black">Upload</button>
        </div>
      </div>
    </div>
  )
}

function TrackRow({ track, remove, update }){
  const wfRef = useRef(null);
  const containerRef = useRef(null);
  const [isReady, setIsReady] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(()=>{
    if (!containerRef.current) return;
    const ws = WaveSurfer.create({
      container: containerRef.current,
      waveColor: '#60a5fa',
      progressColor: '#a78bfa',
      cursorColor: '#fff',
      height: 80,
      responsive: true,
      normalize: true,
    });
    wfRef.current = ws;
    ws.load(track.url);
    ws.on('ready', ()=>{
      setIsReady(true);
      ws.zoom(0);
    });
    ws.on('finish', ()=> setIsPlaying(false));
    return ()=>{ try{ ws.destroy(); } catch(e){} }
  }, [track.url]);

  function playPause(){
    if (!wfRef.current) return;
    wfRef.current.playPause();
    setIsPlaying(wfRef.current.isPlaying());
  }

  function setStart(v){
    update({ start: Number(v) });
  }
  function setEnd(v){
    update({ end: Number(v) });
  }

  async function trimAndExport(){
    const ctx = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(track.buffer.numberOfChannels, Math.ceil((track.end-track.start)*track.buffer.sampleRate), track.buffer.sampleRate);
    const newBuffer = ctx.createBuffer(track.buffer.numberOfChannels, Math.ceil((track.end-track.start)*track.buffer.sampleRate), track.buffer.sampleRate);
    for (let ch=0; ch<track.buffer.numberOfChannels; ch++){
      const old = track.buffer.getChannelData(ch);
      const startIdx = Math.floor(track.start * track.buffer.sampleRate);
      const endIdx = Math.floor(track.end * track.buffer.sampleRate);
      const slice = old.slice(startIdx, endIdx);
      newBuffer.copyToChannel(slice, ch, 0);
    }
    const wavBlob = bufferToWavBlob(newBuffer);
    const url = URL.createObjectURL(wavBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${track.name.replace(/\.[^/.]+$/, '')}_trim_${Math.floor(track.start)}-${Math.floor(track.end)}.wav`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="bg-slate-800 p-3 rounded mb-3">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-medium">{track.name}</div>
          <div className="text-xs text-slate-400">{(track.buffer?.duration||0).toFixed(2)}s</div>
        </div>
        <div className="flex gap-2">
          <button onClick={playPause} className="px-2 py-1 bg-indigo-600 rounded">{isPlaying? 'Pause':'Play'}</button>
          <button onClick={remove} className="px-2 py-1 border rounded">Remove</button>
        </div>
      </div>

      <div className="mt-3">
        <div ref={containerRef} className="w-full bg-black rounded" />
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs">Start (s)</label>
          <input type="range" min={0} max={track.buffer?.duration||1} step="0.01" value={track.start} onChange={e=>setStart(e.target.value)} className="w-full" />
          <div className="text-xs text-slate-400">{track.start.toFixed(2)}</div>
        </div>
        <div>
          <label className="text-xs">End (s)</label>
          <input type="range" min={0} max={track.buffer?.duration||1} step="0.01" value={track.end} onChange={e=>setEnd(e.target.value)} className="w-full" />
          <div className="text-xs text-slate-400">{track.end.toFixed(2)}</div>
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        <button onClick={trimAndExport} className="px-3 py-2 bg-emerald-500 rounded text-black">Trim & Export</button>
      </div>
    </div>
  )
}

// Utility: buffer->wav
function bufferToWavBlob(buffer){
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const bufferArray = new ArrayBuffer(length);
  const view = new DataView(bufferArray);
  writeString(view,0,'RIFF');
  view.setUint32(4,36 + buffer.length * numOfChan *2, true);
  writeString(view,8,'WAVE');
  writeString(view,12,'fmt ');
  view.setUint32(16,16,true);
  view.setUint16(20,1,true);
  view.setUint16(22,numOfChan,true);
  view.setUint32(24,buffer.sampleRate,true);
  view.setUint32(28,buffer.sampleRate * numOfChan *2, true);
  view.setUint16(32,numOfChan*2,true);
  view.setUint16(34,16,true);
  writeString(view,36,'data');
  view.setUint32(40, buffer.length * numOfChan *2, true);
  let offset = 44;
  const channels = [];
  for (let i=0;i<numOfChan;i++) channels.push(buffer.getChannelData(i));
  for (let i=0;i<buffer.length;i++){
    for (let ch=0; ch<numOfChan; ch++){
      let sample = Math.max(-1, Math.min(1, channels[ch][i]));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
      offset += 2;
    }
  }
  return new Blob([view], { type: 'audio/wav' });
}
function writeString(view, offset, string){
  for (let i=0;i<string.length;i++) view.setUint8(offset + i, string.charCodeAt(i));
}
