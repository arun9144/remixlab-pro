            import React from 'react'
            import RemixStudio from './components/RemixStudio.jsx'

            export default function App(){
  return <RemixStudio />
}
